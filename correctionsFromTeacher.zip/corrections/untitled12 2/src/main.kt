fun main(args: Array<String>){
    val hamming = Hamming.compute("GAGGAA", "GGGAAA")
    println("Hamming : $hamming")
}

class Hamming {
    companion object {
        fun compute(dna1: String, dna2: String): Int {
            require(dna1.length == dna2.length) { "left and right strands must be of equal length." }
            return dna1.zip(dna2).count { (val1, val2) -> val1 != val2 }
        }
    }
}